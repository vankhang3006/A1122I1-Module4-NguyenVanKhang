# website_news_basic

HMTL + CSS+ JAVASCRIPT

https://www.youtube.com/watch?v=w2KZO1_zQWs

1. Bố cục website:
- Thư mục html: Lưu các file html.
- Thư mục css: Lưu các file css.
- Thư mục ima: Lưu các file ảnh của website.
- Thư mục js: Lưu các file javascript xử lí sự kiện.
- Thư mục Videos: Lưu file video.

2. Giới thiệu
- File index.html trong thư mục html là file trang chủ
- WEBSITE tĩnh không có cơ sở dữ liệu
+ Mọi bài viết, hình ảnh đều nằm trong code. 
+ Validate nằm trong thư mục js:
 Kiểm tra nhập liệu: email, mật khẩu,...
 kiểm tra kiểu dữ liệu nhập
+ Nhập đủ, đúng thông tin: chuyển đến trang đăng nhập
 Kiểm tra thông tin cũng nằm trong thư mục js: dangnhap.js
 Nhập đúng thông tin đăng nhập chuyển đến diễn đàn.
 Website chưa có CSDL nên đang hardcode kiểm tra đăng nhập.Chưa lưu vào cơ sở dữ liệu
- Tất cả hình ảnh mình lưu tại thư mục img
-  Video thì mình đang dẫn link youtube
 Chỉ có 1 video là lưu tại thư mục videos
- Từng màn hình là 1 file html nên các bạn xem code từng màn hình tại thư mục html với tên tương ứng.
- Trang web mình chưa responsive nên chưa hiển thị đẹp được với tất cả màn hình.
- Mình up code cho một số bạn mới học tham khảo
- Sau khi hoàn thiện các bạn có thể deploy code lên 1 free hosting để cho mọi người có thể xem được.
Link code tham khảo mình để ở dưới.
Chỉ cần tải về. Sau đó giải nén.
Mở thư mục html chạy file index.html là mở trang chủ.
