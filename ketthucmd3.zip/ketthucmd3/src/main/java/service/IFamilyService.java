package service;

import model.Family;

import java.sql.SQLException;
import java.util.List;

public interface IFamilyService {
    List<Family> findAll();
    boolean edit(Family family) throws SQLException;
    Family findById(String familyId);
}
