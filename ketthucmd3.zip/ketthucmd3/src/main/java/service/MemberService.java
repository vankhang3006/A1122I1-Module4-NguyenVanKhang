package service;

import model.Member;
import repository.IMemberRepository;
import repository.MemberRepository;

import java.util.List;

public class MemberService implements IMemberService{
    private IMemberRepository memberRepository = new MemberRepository();

    @Override
    public List<Member> findAllMember(String familyId) {
        return memberRepository.findAllMember(familyId);
    }
}
