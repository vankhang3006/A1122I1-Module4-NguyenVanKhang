package service;

import model.Member;

import java.util.List;

public interface IMemberService {
    List<Member> findAllMember(String familyId);
}
