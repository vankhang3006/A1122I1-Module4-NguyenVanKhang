package service;

import model.Family;
import repository.FamilyRepository;
import repository.IFamilyRepository;

import java.sql.SQLException;
import java.util.List;

public class FamilyService implements IFamilyService{
    private IFamilyRepository familyRepository = new FamilyRepository();

    @Override
    public List<Family> findAll() {
        return familyRepository.findAll();
    }

    @Override
    public boolean edit(Family family) throws SQLException {
        return familyRepository.edit(family);
    }

    @Override
    public Family findById(String familyId) {
        return familyRepository.findById(familyId);
    }

}
