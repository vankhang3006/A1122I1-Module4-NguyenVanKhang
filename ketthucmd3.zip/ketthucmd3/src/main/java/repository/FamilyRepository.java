package repository;

import model.Family;
import model.Member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FamilyRepository implements IFamilyRepository{
    private final String SELECT_ALL ="SELECT * FROM ho_khau;";
    private final String UPDATE_FAMILY ="update ho_khau set ma_ho_khau = ?,ten_chu_ho = ?,so_luong_thanh_vien = ?, ngay_lap = ?, dia_chi = ? where ma_ho_khau = ?;";
    private final String SELECT_FAMILY_BY_ID= "select ma_ho_khau, ten_chu_ho, so_luong_thanh_vien, ngay_lap, dia_chi from ho_khau where ma_ho_khau =?";
    public FamilyRepository() {
    }

    @Override
    public List<Family> findAll() {
        List<Family> familyList = new ArrayList<>();
        // kết nối db
        Connection connection = BaseRepository.getConnectDB();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                String familyId = resultSet.getString("ma_ho_khau");
                String owner = resultSet.getString("ten_chu_ho");
                int numberMember = resultSet.getInt("so_luong_thanh_vien");
                String startDate = resultSet.getString("ngay_lap");
                String address = resultSet.getString("dia_chi");
                Family family = new Family(familyId,owner,numberMember,startDate,address);
                familyList.add(family);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return familyList;
    }

    @Override
    public boolean edit(Family family) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = BaseRepository.getConnectDB(); PreparedStatement statement = connection.prepareStatement(UPDATE_FAMILY);) {
            statement.setString(1, family.getFamilyId());
            statement.setString(2, family.getOwner());
            statement.setInt(3,family.getNumberMember());
            statement.setString(4, family.getStartDate());
            statement.setString(5, family.getAddress());
            statement.setString(6, family.getFamilyId());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    @Override
    public Family findById(String familyId) {
        Family family = null;
        // Step 1: Establishing a Connection
        try (Connection connection = BaseRepository.getConnectDB();
             // Step 2:Create a statement using connection object
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_FAMILY_BY_ID);) {
            preparedStatement.setString(1, familyId);
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                String owner = rs.getString("ten_chu_ho");
                int numberMember = rs.getInt("so_luong_thanh_vien");
                String startDate = rs.getString("ngay_lap");
                String address = rs.getString("dia_chi");
                family = new Family(familyId,owner,numberMember,startDate,address);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return family;
    }

}
