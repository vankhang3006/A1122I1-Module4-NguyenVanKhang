package repository;

import model.Member;
import model.Member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MemberRepository implements IMemberRepository{
    private final String SELECT_MEMBER_NAME_BY_ID = "select ma_thanh_vien,cmnd,ten_thanh_vien,ngay_sinh,ma_ho_khau from thanh_vien where ma_ho_khau = ?";

    public MemberRepository() {
    }

    @Override
    public List<Member> findAllMember(String familyId) {
        List<Member> memberList = new ArrayList<>();
        Connection connection = BaseRepository.getConnectDB();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_MEMBER_NAME_BY_ID);
            preparedStatement.setString(1, familyId);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()){
                int memberId = rs.getInt("ma_thanh_vien");
                double idCard = rs.getDouble("cmnd");
                String name = rs.getString("ten_thanh_vien");
                String birthday = rs.getString("ngay_sinh");
                Member member = new Member(memberId,idCard,name,birthday,familyId);
                memberList.add(member);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return memberList;
    }
}
