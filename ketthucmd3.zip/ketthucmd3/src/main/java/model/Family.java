package model;

public class Family {
    private String familyId;
    private String owner;
    private int numberMember;
    private String startDate;
    private String address;

    public Family() {
    }

    public Family(String familyId, String owner, int numberMember, String startDate, String address) {
        this.familyId = familyId;
        this.owner = owner;
        this.numberMember = numberMember;
        this.startDate = startDate;
        this.address = address;
    }

    public String getFamilyId() {
        return familyId;
    }

    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public int getNumberMember() {
        return numberMember;
    }

    public void setNumberMember(int numberMember) {
        this.numberMember = numberMember;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
