package model;

public class Member {
    private int memberId;
    private double idCard;
    private String name;
    private String birthday;
    private String familyId;

    public Member() {
    }

    public Member(int memberId, double idCard, String name, String birthday, String familyId) {
        this.memberId = memberId;
        this.idCard = idCard;
        this.name = name;
        this.birthday = birthday;
        this.familyId = familyId;
    }

    public Member(double idCard, String name, String birthday, String familyId) {
        this.idCard = idCard;
        this.name = name;
        this.birthday = birthday;
        this.familyId = familyId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public double getIdCard() {
        return idCard;
    }

    public void setIdCard(double idCard) {
        this.idCard = idCard;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getFamilyId() {
        return familyId;
    }

    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }
}
