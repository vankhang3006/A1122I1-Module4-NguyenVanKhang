package controller;

import model.Family;
import model.Member;
import service.FamilyService;
import service.IFamilyService;
import service.IMemberService;
import service.MemberService;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "controller.FamilyServlet", value = "/family")
public class FamilyServlet extends HttpServlet {
    private IFamilyService familyService = new FamilyService();
    private IMemberService memberService = new MemberService();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action==null){
            action ="";
        }
        try {
            switch (action){
                case "edit":
                    showEditForm(request,response);
                    break;
                case "find":
                    showMember(request, response);
                    break;
                default:
                    showList(request,response);

            }
        }catch (SQLException ex) {
            throw new ServletException(ex);
        }

    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        String familyId = request.getParameter("id");
        Family existingFamily = familyService.findById(familyId);
        RequestDispatcher dispatcher = request.getRequestDispatcher("family/edit.jsp");
        request.setAttribute("family", existingFamily);
        dispatcher.forward(request, response);
    }

    private void showList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String familyId = request.getParameter("id");
        List<Family> familyList = familyService.findAll();
        List<Member> memberList = memberService.findAllMember(familyId);
        request.setAttribute("familyList", familyList);
        request.setAttribute("memberList", memberList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("family/list.jsp");
        dispatcher.forward(request, response);
    }
    private void showMember(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String familyId = request.getParameter("id");
        List<Member> memberList = memberService.findAllMember(familyId);
        request.setAttribute("memberList", memberList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("family/family-members.jsp");
        dispatcher.forward(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action==null){
            action ="";
        }
        try {
            switch (action){
                case "edit":
                    editFamily(request,response);
                    break;

            }
        }catch (SQLException ex){
            throw new ServletException(ex);
        }

    }

    private void editFamily(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
            String familyId = request.getParameter("familyId");
            String owner = request.getParameter("owner");
            int numberMember = Integer.parseInt(request.getParameter("numberMember"));
            String startDate = request.getParameter("startDate");
            String address = request.getParameter("address");
            Family book = new Family(familyId,owner,numberMember,startDate,address);
            boolean check = familyService.edit(book);
            String mess ="Cập nhật thành công";
            if (!check){
                mess= "Cập nhật không thành công";
                request.setAttribute("mess", mess);
                showEditForm(request,response);
            }
            request.setAttribute("mess", mess);
            showList(request,response);
            RequestDispatcher dispatcher = request.getRequestDispatcher("family/edit.jsp");
            dispatcher.forward(request, response);
            }

}
